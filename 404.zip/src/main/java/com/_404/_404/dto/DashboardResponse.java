package com._404._404.dto;

import java.util.List;

public record DashboardResponse(
		String now,
		Cards cards,
		ShareChart serviceStatus,
		List<TrendPoint> weeklyTrend,
		ShareChart memberStatus,
		List<TrainRow> trains,
		List<StationRow> stations) {

	public record Cards(CountCard members, CountCard notices, CountCard qnaPending, ServiceCard services) {
	}

	public record CountCard(long count, long diffFromYesterday) {
	}

	public record ServiceCard(long total, long normal) {
	}

	public record ShareChart(long total, List<Share> shares) {
	}

	public record Share(String code, String label, long count, double percent) {
	}

	public record TrendPoint(String date, long normal, long maintenance, long fault) {
	}

	public record TrainRow(Long id, String status, String statusLabel, String route,
						   String trainNo, String driver, String direction, String directionLabel) {
	}

	public record StationRow(Long id, String status, String statusLabel, String name,
							 String stationNo, String staff) {
	}
}
